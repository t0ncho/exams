

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `price` varchar(30) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `url` varchar(30) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","5.04","2012-02-01","blala","1");
INSERT INTO article VALUES("2","5.04","2012-02-01","blala","2");
INSERT INTO article VALUES("3","5.04","2012-02-01","blala","3");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(40) DEFAULT NULL,
  `created_by` varchar(30) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","dfghj","GOGO","2");
INSERT INTO category VALUES("2","dfghj","GOGO","2");
INSERT INTO category VALUES("3","dfghj","GOGO","1");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(20) DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","kon","2");
INSERT INTO tag VALUES("2","sopol","1");
INSERT INTO tag VALUES("3","gevrek","3");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(20) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `name` varchar(40) DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","ghjk","20","GOGO","1");
INSERT INTO user VALUES("2","ghjkl","30","PACO","2");
INSERT INTO user VALUES("3","dsfghj","30","NASKO","3");



--------------------------------------------------------------------------Saturday 26th of April 2014 12:20:15 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `price` varchar(30) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `url` varchar(30) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","5.04","2012-02-01","blala","1");
INSERT INTO article VALUES("2","5.04","2012-02-01","blala","2");
INSERT INTO article VALUES("3","5.04","2012-02-01","blala","3");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(40) DEFAULT NULL,
  `created_by` varchar(30) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","dfghj","GOGO","2");
INSERT INTO category VALUES("2","dfghj","GOGO","2");
INSERT INTO category VALUES("3","dfghj","GOGO","1");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(20) DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","kon","2");
INSERT INTO tag VALUES("2","sopol","1");
INSERT INTO tag VALUES("3","gevrek","3");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(20) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `name` varchar(40) DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","ghjk","20","GOGO","1");
INSERT INTO user VALUES("2","ghjkl","30","PACO","2");
INSERT INTO user VALUES("3","dsfghj","30","NASKO","3");



--------------------------------------------------------------------------Saturday 26th of April 2014 12:22:08 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `price` varchar(30) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `url` varchar(30) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","5.04","2012-02-01","blala","1");
INSERT INTO article VALUES("2","5.04","2012-02-01","blala","2");
INSERT INTO article VALUES("3","5.04","2012-02-01","blala","3");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(40) DEFAULT NULL,
  `created_by` varchar(30) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","dfghj","GOGO","2");
INSERT INTO category VALUES("2","dfghj","GOGO","2");
INSERT INTO category VALUES("3","dfghj","GOGO","1");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(20) DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","kon","2");
INSERT INTO tag VALUES("2","sopol","1");
INSERT INTO tag VALUES("3","gevrek","3");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(20) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `name` varchar(40) DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","ghjk","20","GOGO","1");
INSERT INTO user VALUES("2","ghjkl","30","PACO","2");
INSERT INTO user VALUES("3","dsfghj","30","NASKO","3");



--------------------------------------------------------------------------Saturday 26th of April 2014 12:22:20 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `price` varchar(30) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `url` varchar(30) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","5.04","2012-02-01","blala","1");
INSERT INTO article VALUES("2","5.04","2012-02-01","blala","2");
INSERT INTO article VALUES("3","5.04","2012-02-01","blala","3");





CREATE TABLE `category_part1` (
  `category_id1` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`category_id1`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category_part1 VALUES("1","dfghj");
INSERT INTO category_part1 VALUES("2","dfghj");
INSERT INTO category_part1 VALUES("3","dfghj");





CREATE TABLE `category_part2` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_by` varchar(30) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category_part2 VALUES("1","GOGO","2");
INSERT INTO category_part2 VALUES("2","GOGO","2");
INSERT INTO category_part2 VALUES("3","GOGO","1");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(20) DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","kon","2");
INSERT INTO tag VALUES("2","sopol","1");
INSERT INTO tag VALUES("3","gevrek","3");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(20) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `name` varchar(40) DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","ghjk","20","GOGO","1");
INSERT INTO user VALUES("2","ghjkl","30","PACO","2");
INSERT INTO user VALUES("3","dsfghj","30","NASKO","3");



--------------------------------------------------------------------------Saturday 26th of April 2014 12:24:32 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `price` varchar(30) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `url` varchar(30) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","5.04","2012-02-01","blala","1");
INSERT INTO article VALUES("2","5.04","2012-02-01","blala","2");
INSERT INTO article VALUES("3","5.04","2012-02-01","blala","3");





CREATE TABLE `category_part1` (
  `category_id1` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`category_id1`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category_part1 VALUES("1","dfghj");
INSERT INTO category_part1 VALUES("2","dfghj");
INSERT INTO category_part1 VALUES("3","dfghj");





CREATE TABLE `category_part2` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_by` varchar(30) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category_part2 VALUES("1","GOGO","2");
INSERT INTO category_part2 VALUES("2","GOGO","2");
INSERT INTO category_part2 VALUES("3","GOGO","1");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(20) DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","kon","2");
INSERT INTO tag VALUES("2","sopol","1");
INSERT INTO tag VALUES("3","gevrek","3");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(20) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `name` varchar(40) DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","ghjk","20","GOGO","1");
INSERT INTO user VALUES("2","ghjkl","30","PACO","2");
INSERT INTO user VALUES("3","dsfghj","30","NASKO","3");



--------------------------------------------------------------------------Saturday 26th of April 2014 12:29:09 PM